var judul = document.getElementById("judul");

var ubahJudulBtn = document.getElementById("ubahJudulBtn");

var teksAsli = judul.innerText;

ubahJudulBtn.addEventListener("click", function() {
    
    if (judul.innerText === teksAsli) {
        
        judul.innerText = "CuingPEDD!!";
    } else {
        
        judul.innerText = teksAsli;
    }
});

